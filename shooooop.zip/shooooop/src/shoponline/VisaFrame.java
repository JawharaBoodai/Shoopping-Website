/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shoponline;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VisaFrame extends JFrame {

    
    JLabel lbl1,lbl2;
    JTextField f1,f2;
    JButton pay;
    VisaHandler handler = new VisaHandler();
    public VisaFrame() {
        
        
        super("Visa Pay");
        setContentPane(new JLabel(new ImageIcon(getClass().getResource("FirstFrame2.jpg"))));
        setResizable(false);
        setLayout(new FlowLayout());
         lbl1= new JLabel("Expiry date");
         lbl2= new JLabel("CVV");
         f1= new JTextField("DD/MM/YY");
         f2= new JTextField(3);
         pay = new JGradientButton("pay", Color.GRAY, Color.BLACK);;
       add(lbl1);
       add(f1);
       add(lbl2);
       add(f2);
       add(pay);
       pay.addActionListener(handler);
    }
    
    public class VisaHandler implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            dispose();
        }
    }
    
}
