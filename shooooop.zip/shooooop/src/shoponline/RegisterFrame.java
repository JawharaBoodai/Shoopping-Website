
package shoponline;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class RegisterFrame extends JFrame {
  
  
    JLabel rusername;
    JLabel rpassword;
    JLabel remail;
    JLabel rphone;
    JTextField name;
    JPasswordField pass;
    JTextField email;
    JTextField phone;
    JButton submit,cancle;
    JPanel reg;
    JPanel sub;
    
    RegisterHandler handler = new RegisterHandler();
    
    RegisterFrame()
    {
        super("Register Frame");
        setLayout(null);
        setContentPane(new JLabel(new ImageIcon(getClass().getResource("FirstFrame2.jpg"))));
        setResizable(false);
        
        reg = new JPanel();
        sub = new JPanel();
        reg.setLayout(new BoxLayout(reg,BoxLayout.Y_AXIS));
        rusername = new JLabel("Username:");
        name = new JTextField(10);
        
        rpassword = new JLabel("Password:");
        pass = new JPasswordField(10);
        
        remail = new JLabel("Email:");
        email = new JTextField(10);
        
        rphone = new JLabel("Phone Number:");
        phone = new JTextField(10);
        
        submit = new JGradientButton("Submit", Color.GRAY, Color.BLACK);
        cancle = new JGradientButton("Cancel", Color.GRAY, Color.BLACK);
        
        reg.add(rusername);
        reg.add(name);
        reg.add(rpassword);
        reg.add(pass);
        reg.add(remail);
        reg.add(email);
        reg.add(rphone);
        reg.add(phone);
        sub.add(submit);
        sub.add(cancle);
       // reg.setPreferredSize(new Dimension(200,200));
       
       reg.setBounds(370, 270, 250, 190);
       sub.setBounds(400, 470, 200, 50);
        add(reg);
        add(sub);
       submit.addActionListener(handler);
       cancle.addActionListener(handler);
    }
    
     public class RegisterHandler implements ActionListener
   {
       public void actionPerformed(ActionEvent e)
       {
           if(e.getSource()==submit)
           {             
               
            String username = name.getText();
            String password = pass.getText();
            String eemail = email.getText();
            String phonenumber = phone.getText();
            
            Connection con = null;
            String DBURL ="JDBC:MySql://localhost:3306/shoponline?useSSL=true";
            String USER ="root";
            String PASSWORD ="Kjs70190";

            try {
                con = DriverManager.getConnection(DBURL, USER, PASSWORD);
                Statement statement = con.createStatement();
                String sql = String.format("Insert into users(username,password,email,phonenumber)Values('%s','%s','%s','%s')",username,password,eemail,phonenumber);
                statement.executeUpdate(sql);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
               
               
           }
           
           else if(e.getSource()==cancle)
           {
             name.setText("");
             pass.setText("");
             email.setText("");
             phone.setText("");
             setVisible(false);
           }
           
          
       }
   }
    
    
    
    
    
}
