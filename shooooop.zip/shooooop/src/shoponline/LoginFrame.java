
package shoponline;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginFrame extends JFrame {
    
  JLabel log;
  JLabel username;
  JLabel password;
  JTextField usertext;
  JPasswordField passtext;
  JButton submit;
  Font f;
  private LoginFrame instance = null;
  LoginHandler handler= new LoginHandler();
  JPanel login;
    LoginFrame()
    {
      super("Login");
      instance = this;
      setLayout(null);
      setContentPane(new JLabel(new ImageIcon(getClass().getResource("FirstFrame2.jpg"))));
      setResizable(false);
      login = new JPanel();
      login.setLayout(new BoxLayout(login,BoxLayout.Y_AXIS));
      JLabel welcomeLbl = new JLabel("Wecome back");
      welcomeLbl.setFont(new Font("TimesRoman", Font.BOLD, 30));
      welcomeLbl.setForeground(Color.gray);
      welcomeLbl.setBounds(400, -120, 500, 500);
      add(welcomeLbl);
      
      username = new JLabel("Username:");
      usertext = new JTextField(15);
     login.add(username);
     login.add(usertext);
      
      password = new JLabel("Password:");
      passtext = new JPasswordField(15);
      login.add(password);
      login.add(passtext);
    
      submit = new JGradientButton("Submit", Color.GRAY, Color.BLACK);
      login.setBounds(370, 300, 250, 90);
      submit.setBounds(435, 412, 100, 35);
      add(login);
      add(submit);
      submit.addActionListener(handler);
    }
     public class LoginHandler implements ActionListener
   {
       public void actionPerformed(ActionEvent e)
       {
           
            if(e.getSource()==submit)        
            {
            String username = usertext.getText();
            String password = passtext.getText();
            
            Connection con = null;
            String DBURL ="JDBC:MySql://localhost:3306/shoponline?useSSL=true";
            String USER ="root";
            String PASSWORD ="Kjs70190";

            try {
                con = DriverManager.getConnection(DBURL, USER, PASSWORD);
                //Statement statement = con.createStatement();
                 
                String sql = "select username, password from users where username = ? and password = ? ";
                PreparedStatement statement = con.prepareStatement(sql);
                statement.setString(1,username);
                statement.setString(2,password);
                ResultSet result = statement.executeQuery();
                
                
                
                if(result.next())
                {
        Products pfrm = new Products(instance, null, null);
        pfrm.setSize(900,900);
        pfrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        pfrm.setVisible(true);
                }
                
                else
                {
                    JOptionPane.showMessageDialog(null,"This User Does not exists");  
                }
                            } catch (SQLException ex) {
               ex.printStackTrace();
            }
                
//           if(e.getSource()==submit)
//           {
//         Products pfrm = new Products();
//         pfrm.setSize(900,900);
//         pfrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//         pfrm.setVisible(true);
//               
//           }
       }
          
       }
   }
}
