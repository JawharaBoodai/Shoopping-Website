
package shoponline;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FirstFrame extends JFrame{
    
    JLabel lbl,log;
    JButton login;
    JButton register;
    JPanel pnl;
    BorderLayout layout;
    Font font;
    
    LoginHandler handler = new LoginHandler();
    
    FirstFrame()
    {
 super("Welcome");
       //layout = new BorderLayout(5,5);
           JLabel container = new JLabel(new ImageIcon(getClass().getResource("FirstFrame2.jpg")));     //here
           container.setLayout(null);                                                          //here
      // Icon logo= new ImageIcon(getClass().getResource("logoo.png"));
      // log = new JLabel(logo);
      // log.setBounds(-170,-160, 500, 500);
      // container.add(log);                                                                  //here
        lbl = new JLabel("BridesMaids Online Shop");
        font = new Font("TimesRoman",Font.BOLD,30);
        lbl.setFont(font);
        lbl.setForeground(Color.gray);
        lbl.setBounds(300, -120,500,500);
        container.add(lbl);                                                                  //here     
        login = new JGradientButton("Login", Color.GRAY, Color.BLACK);
        container.add(login);                                                                //here
        register = new JGradientButton("Register", Color.GRAY, Color.BLACK);
        //pnl = new JPanel();
        //pnl.add(login);
        //pnl.add(register);
       // pnl.setBounds(220,250,150,150);
       login.setBounds(360,450,250,70);
       register.setBounds(360,350,250,70);
               add(container);                                                             //here
//        add(log);
//        add(lbl);
//        add(login);
                container.add(register);                                                   //here
        login.addActionListener(handler);
        register.addActionListener(handler);
        
        
    }
    
   public class LoginHandler implements ActionListener
   {
       public void actionPerformed(ActionEvent e)
       {
           if(e.getSource()==login)
           {
         LoginFrame frm1 = new LoginFrame();
         frm1.setSize(1000,800);
         frm1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         frm1.setVisible(true);
               
           }
           
           if(e.getSource()==register)
           {
              RegisterFrame frm2 = new RegisterFrame();
              frm2.setSize(1000,800);
              frm2.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
              frm2.setVisible(true);
           }
       }
   }
}
