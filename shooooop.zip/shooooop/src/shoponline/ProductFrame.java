
package shoponline;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;




public class ProductFrame extends JFrame{
JButton submitbtn;
JButton goback;
JPanel panle;
JPanel product;
String Size0 []={"Select size:","L","M","S"};
JComboBox Size;
Products productsFrame;
private ProductFrame instance = null;
//private RegisterFrame regInstance = null;
//ProductFrameHandler handler = new ProductFrameHandler();



public ProductFrame(int id) {
    

        super("Product");
        setContentPane(new JLabel(new ImageIcon(getClass().getResource("FirstFrame2.jpg"))));
        setResizable(false);
        instance = this;
        int ee =id;
//        JOptionPane.showMessageDialog(rootPane, "Product id is "+id );
        setLayout(new FlowLayout());
        //Image  
        
        //Size CommboBox
        
         Size= new JComboBox(Size0);
        //Submit Button
        submitbtn=new JButton("Add to Cart");
        goback = new JButton("Cancel");
        panle = new JPanel();
        panle.add(submitbtn);
        panle.add(goback);
        
        
        
        
        product = new JPanel();
        
        product.setPreferredSize(new Dimension(300,500));
        
        
            Connection con = null;
            String DBURL ="JDBC:MySql://localhost:3306/shoponline?useSSL=true";
            String USER ="root";
            String PASSWORD ="Kjs70190";
        
        
         
            String productname ="";
            String price = "";
            String description ="";
        
            
             try {
                con = DriverManager.getConnection(DBURL, USER, PASSWORD);
                
                Statement statement = con.createStatement();
                String sql = String.format("select productId,productName,price,description from products where productId='%s'",id);
                ResultSet result = statement.executeQuery(sql);
                
                
                while(result.next())
                {
                    
              Icon Dress = new ImageIcon(getClass().getResource(result.getObject("productId")+".jpg"));
              product.add(new JLabel(Dress));
              product.add (new JLabel(result.getString("productName")));
              product.add (new JLabel("Price: "+result.getString("PRICE")));
              product.add (new JLabel("Description:"+result.getString("description")));

                }

             }
              catch (SQLException ex) {
               ex.printStackTrace();
            }
        
        
        
      
        
        add(Size);
        add(product);
        add(panle);
       submitbtn.addActionListener(
       
       new ActionListener()
               {
                   public void actionPerformed(ActionEvent e)
                   {
                       
                       
                       
                       productsFrame = new Products(null, null, instance);
                       productsFrame.setVisible(true);
               String sizenumber;
               //int id1=id;
               sizenumber = Size.getSelectedItem().toString();
               //JOptionPane.showMessageDialog(null,sizenumber);
               
               
    
   Connection con = null;
            String DBURL ="JDBC:MySql://localhost:3306/shoponline?useSSL=true";
            String USER ="root";
            String PASSWORD ="Kjs70190";

            try {
                con = DriverManager.getConnection(DBURL, USER, PASSWORD);
                //Statement statement = con.createStatement();
                 
                String sql1 = String.format("select itemid,size,productid_fk from items where size='%s' and productid_fk='%s'",sizenumber,id);
                PreparedStatement statement = con.prepareStatement(sql1);
                ResultSet result = statement.executeQuery();
                
             int f= result.getInt("itemid");
              
                        
                
                while(result.next())
                {
                    
           JOptionPane.showMessageDialog(null,"This item exists"); 
//                    
//             String username = name.getText();
//            String password = pass.getText();
//            String eemail = email.getText();
//            String phonenumber = phone.getText();
            
//            Connection con = null;
//            String DBURL ="JDBC:MySql://localhost:3306/shoponline?useSSL=true";
//            String USER ="root";
//            String PASSWORD ="Kjs70190";

//            try {
//                con = DriverManager.getConnection(DBURL, USER, PASSWORD);
//                 Statement statement1 = con.createStatement();
//                String sql =("Insert into cart(itemid_FK)Values()");
//                String sql = String.format("Insert into cart(itemid)Values('%s')");
//                
//                       
//                statement.executeUpdate(sql);
//            } catch (SQLException ex) {
//                ex.printStackTrace();
//            }
//    
//    
//    
//    
//    
//    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
                    
                }
                
//                else
//                {
//                    JOptionPane.showMessageDialog(null,"This item Does not exists");  
//                }
                            } catch (SQLException ex) {
               ex.printStackTrace();
            }
                       
                   }
               }
       
        
                   
       );
       
       
       

       
       //goback.addActionListener(handler);
        }
    }
//        public class ProductFrameHandler implements ActionListener
//   {
//       public void actionPerformed(ActionEvent e)
//       {
//           
//           
////               String sizenumber;
////               int id1=id;
////               sizenumber = Size.getSelectedItem().toString();
////               //JOptionPane.showMessageDialog(null,sizenumber);
////               
////               
////               
////               
////        if(e.getSource()==submitbtn)
////        {
////            
////   Connection con = null;
////            String DBURL ="JDBC:MySql://localhost:3306/shoponline?useSSL=true";
////            String USER ="root";
////            String PASSWORD ="Kjs70190";
////
////            try {
////                con = DriverManager.getConnection(DBURL, USER, PASSWORD);
////                //Statement statement = con.createStatement();
////                 
////    String sql = String.format("select size,productid_fk from items where size='%s' and productid_fk='%s'",sizenumber,ee);
////                PreparedStatement statement = con.prepareStatement(sql);
////                statement.setString(2,sizenumber);
////                statement.setString(3,e);
////                
////                ResultSet result = statement.executeQuery();
////                
////                
////                
////                while(result.next())
////                {
////    JOptionPane.showMessageDialog(null,"This item exists"); 
////                    
////                }
////                
//////                else
//////                {
//////                    JOptionPane.showMessageDialog(null,"This item Does not exists");  
//////                }
////                            } catch (SQLException ex) {
////               ex.printStackTrace();
////            }
//            
//            
//
//            
//            
//            
////        }
//           if(e.getSource()==goback)
//           {
//       dispose();
//           }
//       }
//       }
//               }
