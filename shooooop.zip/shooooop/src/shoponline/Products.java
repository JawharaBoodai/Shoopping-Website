
package shoponline;



import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

// 1. Create the product table. DONE
//2. Put some data in the product table. DONE
//3. Create Select Query to retreive everything from the product table. DONE
// 4. While resultset object has some rows increment a vaiable that will store the no of products, and go to the next row.
// 5. Create an array of JButtons based on the no of products.
// 6. when creating the Jbuttons for the products, 
//4. Create a button for every product in the products table.

//
public class Products extends JFrame{ 
ProductHandler handler= new ProductHandler();
JButton CartBtn;
JButton[] btn ;
ProductFrame productFrame;
int i;
    public Products(LoginFrame logFrame, RegisterFrame regFrame, ProductFrame pFrame) {
    super("View Products");
    setContentPane(new JLabel(new ImageIcon(getClass().getResource("FirstFrame2.jpg"))));
    setResizable(false);
    productFrame = pFrame;

    setLayout(new FlowLayout());
            
            GridLayout grid = new GridLayout(1, 4);
            JPanel panel = new JPanel(grid);
            JScrollPane scrollPane = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            scrollPane.setBorder(BorderFactory.createEmptyBorder());
            getContentPane().add(scrollPane, BorderLayout.CENTER);
 
            
            Connection con = null;
            String DBURL ="JDBC:MySql://localhost:3306/shoponline?useSSL=true";
            String USER ="root";
            String PASSWORD ="Kjs70190";
            CartBtn= new JGradientButton("Go to Cart", Color.GRAY, Color.BLACK);
            
            
            i=0;
            
            try {
                con = DriverManager.getConnection(DBURL, USER, PASSWORD);
                Statement statement = con.createStatement();
                String sql = "select productId, productName, price,description from products";
                ResultSet result = statement.executeQuery(sql);
                
                int productCount =0;
                // Count number of products retreived 
                
                while(result.next()){
                    productCount++;
                }
                
                System.out.println(productCount);
                
                btn = new JGradientButton[productCount];
                result.beforeFirst();
                
                while (result.next()){
                
//                Icon Dress= new ImageIcon(getClass().getResource(result.getObject("ProductId")+".jpeg");
                                   
                    Icon Dress = new ImageIcon(getClass().getResource(result.getObject("productId")+".jpg"));
                    Image img = ((ImageIcon) Dress).getImage() ;  
                    Image newimg = img.getScaledInstance( 150, 250, java.awt.Image.SCALE_SMOOTH );
                    Dress = new ImageIcon( newimg );
                    btn[i].setIcon(Dress);
                    btn[i].setContentAreaFilled(false);
                    btn[i].setPreferredSize(new Dimension(150, 300));
                    panel.add(btn[i]);
                    btn[i].addActionListener(handler);
                    i++;
                                          
                
                }
            }
               catch (SQLException ex) {
               ex.printStackTrace();
            }
 
            add(CartBtn);
            CartBtn.addActionListener(handler);
            
                             
    }
       public class ProductHandler implements ActionListener
   {
       public void actionPerformed(ActionEvent e)
       {
           if (e.getSource()==CartBtn)
           {
               
         CartFrame frm = new CartFrame();
         frm.setSize(500,600);
         frm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         frm.setVisible(true);
           }
          
           else
           {
               for(int i = 0; i<btn.length; i++){
                            
                            if(e.getSource()== btn[i]){
                            ProductFrame frm = new ProductFrame(i+1);
                            frm.setSize(500,650);
                            frm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                            frm.setVisible(true);
                            }
                        }
            }
           setVisible(false);
            if( productFrame != null )
                productFrame.setVisible(true);
           }
          
       }
       }

