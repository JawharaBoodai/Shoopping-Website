
package shoponline;

import javax.swing.JFrame;


public class ShopOnline {

    public static void main(String[] args) {
        FirstFrame frm = new FirstFrame();
        frm.setSize(1000,800);
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.setVisible(true);
       
    }
    
}
