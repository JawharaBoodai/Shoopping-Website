
package shoponline;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class OrderFrame extends JFrame {
ButtonGroup payment,delivery;
JRadioButton rbtn1,rbtn2,rbtn3,rbtn4;
JLabel lbl,lbl1,lbl2;
JTextArea text;
JButton btn;

    public OrderFrame() {
        
    super("Place Order");
    setContentPane(new JLabel(new ImageIcon(getClass().getResource("FirstFrame2.jpg"))));
    setResizable(false);
    Box box = Box.createVerticalBox();
         btn= new JGradientButton("Place Order", Color.GRAY, Color.BLACK);
        lbl= new JLabel("Payment method");
        rbtn1 = new JRadioButton( "Cash on delivery");
        rbtn2 = new JRadioButton( "Visa" );
        lbl1 = new JLabel("Adress");
        text = new JTextArea(4,3);
        lbl2 = new JLabel("Delivery Option");
        rbtn3 = new JRadioButton( "free");
        rbtn4 = new JRadioButton( "$33.50" );
        
        delivery = new ButtonGroup();
        delivery.add(rbtn3);
        delivery.add(rbtn4);
        
        
        payment = new ButtonGroup();
        payment.add(rbtn1);
        payment.add(rbtn2);
        
       
        
      box.add(lbl1);
      box.add(text);
      box.add(lbl2);
      box.add(rbtn3);
      box.add(rbtn4);
      box.add(lbl);
      box.add(rbtn1);
      box.add(rbtn2);
      box.add(btn);
      add(box);
        rbtn2.addItemListener(new OrderHandler());
        btn.addActionListener(new OrderEvent());
    }
    private class OrderHandler implements ItemListener 
    {

        @Override
        public void itemStateChanged(ItemEvent e) {
          if (rbtn2.isSelected())
          {
         VisaFrame vfrm = new VisaFrame();
         vfrm.setSize(200,200);
         vfrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         vfrm.setVisible(true);
         
          }
          
          
        }

              
        }
    
    
    public class OrderEvent implements ActionListener
    {
      public void actionPerformed(ActionEvent e)
      {
          if(e.getSource()==btn)
          {
              JOptionPane.showMessageDialog(null, "You order is placed Successfully", "Order is done",JOptionPane.INFORMATION_MESSAGE);
          }
      }
    }
    }

