
package shoponline;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CartFrame extends JFrame{
JButton btn1;
JButton goback;
BorderLayout layout;
JPanel pnl1,pnl2;
JTextArea text;
JLabel lbl1,lbl2;
    public CartFrame() {
        super("Cart");
        setLayout(new FlowLayout());
        setContentPane(new JLabel(new ImageIcon(getClass().getResource("FirstFrame2.jpg"))));
        setResizable(false);
        
        pnl1 = new JPanel();
        pnl1.setBackground(Color.white);
        pnl1.setPreferredSize(new Dimension(300,500));
        
        JScrollPane scrollPane = new JScrollPane(pnl1, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        text = new JTextArea(5,5);
        text.setEditable(false);
        lbl1 = new JLabel("Total Price");
        
        btn1 = new JGradientButton("Check Out", Color.GRAY, Color.BLACK);
        goback = new JGradientButton("Cancel", Color.GRAY, Color.BLACK);
        
        add(scrollPane);
        add(lbl1);
        add(text);
        add(btn1);
        add(goback);
        
        CartHandler handler = new CartHandler();
        
      btn1.addActionListener(handler);
      goback.addActionListener(handler);

        
    }
    
    public class CartHandler implements ActionListener
   {
       public void actionPerformed(ActionEvent e)
       {
           if(e.getSource()==btn1)
           {
         OrderFrame frm = new OrderFrame();
         frm.setSize(400,300);
         frm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         frm.setVisible(true);    
           }
           
           
         if(e.getSource()==goback)
         {
             dispose();
             setVisible(false);
         }
       }
       }
    
}
